# language: pt
@extrato
Funcionalidade: Consulta do extrato
  Quero consultar as movimentações da minha conta
  Para conferir as operações que realizei

  Contexto:
    Dado que estou logado no BugBank com uma conta de demonstração

  @positivo
  Cenário: Abrir o extrato da conta
    Quando acesso a opção de extrato
    Então devo visualizar o histórico de movimentações disponível

  @consistencia
  Cenário: Conferir uma transferência no extrato
    Dado que realizei uma transferência com sucesso
    Quando acesso o extrato da conta de origem
    Então devo encontrar a transferência no histórico
    E o valor exibido deve ser o mesmo que foi transferido

  @consistencia
  Cenário: Conferir se o extrato mostra a movimentação mais recente
    Dado que realizei uma transferência há pouco tempo
    Quando abro o extrato da conta
    Então a movimentação mais recente deve aparecer no histórico
    E as informações devem corresponder à transferência realizada
