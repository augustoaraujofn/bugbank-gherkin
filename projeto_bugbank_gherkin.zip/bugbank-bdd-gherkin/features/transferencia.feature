# language: pt
@transferencia
Funcionalidade: Transferência entre contas
  Quero enviar dinheiro para outra conta do BugBank
  Para movimentar meu saldo

  Contexto:
    Dado que estou logado em uma conta de demonstração
    E tenho os dados de uma segunda conta do BugBank

  @positivo @smoke
  Cenário: Transferir um valor dentro do saldo disponível
    Quando acesso a opção de transferência
    E informo os dados da conta de destino
    E digito um valor menor que o saldo disponível
    E confirmo a transferência
    Então a transferência deve ser concluída
    E a aplicação deve apresentar uma confirmação
    E o saldo da minha conta deve diminuir pelo valor transferido

  @negativo
  Cenário: Tentar transferir um valor maior que o saldo disponível
    Quando acesso a opção de transferência
    E informo os dados da conta de destino
    E digito um valor maior que o saldo disponível
    E confirmo a transferência
    Então a aplicação não deve concluir a transferência
    E deve informar que não há saldo suficiente

  @negativo
  Cenário: Tentar transferir o valor zero
    Quando acesso a opção de transferência
    E informo os dados da conta de destino
    E digito o valor zero
    E confirmo a transferência
    Então a aplicação deve impedir a operação
    E deve informar que o valor não é válido

  @negativo
  Cenário: Tentar transferir para uma conta que não existe
    Quando acesso a opção de transferência
    E informo dados de uma conta de destino inexistente
    E digito um valor válido
    E confirmo a transferência
    Então a aplicação não deve concluir a operação
    E deve informar que a conta de destino não foi encontrada

  @consistencia
  Cenário: Conferir os saldos das duas contas depois da transferência
    Dado que sei o saldo inicial das duas contas
    Quando faço uma transferência válida da minha conta para a segunda conta
    Então o saldo da minha conta deve diminuir pelo valor enviado
    E o saldo da conta de destino deve aumentar pelo mesmo valor
