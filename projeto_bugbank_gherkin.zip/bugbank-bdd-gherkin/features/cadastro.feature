# language: pt
@cadastro
Funcionalidade: Cadastro de conta
  Quero criar uma conta no BugBank
  Para conseguir acessar e usar a aplicação

  Contexto:
    Dado que estou na página inicial do BugBank

  @positivo
  Cenário: Criar uma conta preenchendo os dados corretamente
    Quando acesso a opção de registrar
    E informo um e-mail que ainda não foi usado
    E preencho meu nome
    E informo uma senha
    E repito a mesma senha na confirmação
    E clico em cadastrar
    Então minha conta deve ser criada
    E a aplicação deve informar que o cadastro foi realizado

  @negativo
  Cenário: Tentar cadastrar sem preencher os campos obrigatórios
    Quando acesso a opção de registrar
    E clico em cadastrar sem preencher os campos
    Então a aplicação deve avisar que existem campos obrigatórios
    E não deve criar a conta

  @negativo
  Cenário: Informar um e-mail em formato inválido
    Quando acesso a opção de registrar
    E preencho o nome e as senhas corretamente
    Mas informo um e-mail em formato inválido
    E clico em cadastrar
    Então a aplicação deve indicar que o e-mail não é válido
    E não deve criar a conta

  @negativo
  Cenário: Confirmar uma senha diferente da senha informada
    Quando acesso a opção de registrar
    E preencho os demais campos corretamente
    Mas digito senhas diferentes nos campos de senha e confirmação
    E clico em cadastrar
    Então a aplicação deve avisar que as senhas não coincidem
    E não deve criar a conta

  @regra-de-negocio
  Cenário: Tentar cadastrar novamente com um e-mail já utilizado
    Dado que já existe uma conta cadastrada com determinado e-mail
    Quando tento criar outra conta usando esse mesmo e-mail
    Então o BugBank deve impedir o novo cadastro
    E deve apresentar uma mensagem explicando o motivo

  @saldo-inicial
  Cenário: Criar uma conta com a opção de saldo inicial marcada
    Quando acesso a opção de registrar
    E preencho os dados de cadastro corretamente
    E marco a opção "Criar conta com saldo"
    E clico em cadastrar
    Então a conta deve ser criada
    E o saldo inicial deve seguir a regra definida para essa opção

  @saldo-inicial
  Cenário: Criar uma conta sem marcar a opção de saldo inicial
    Quando acesso a opção de registrar
    E preencho os dados de cadastro corretamente
    E deixo desmarcada a opção "Criar conta com saldo"
    E clico em cadastrar
    Então a conta deve ser criada
    E o saldo inicial deve seguir a regra definida para a opção desmarcada
