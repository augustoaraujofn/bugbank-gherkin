# language: pt
@conta
Funcionalidade: Consulta da conta
  Quero consultar minha conta
  Para conferir meus dados e meu saldo

  Contexto:
    Dado que estou logado no BugBank com uma conta de demonstração

  @positivo
  Cenário: Consultar as informações da conta
    Quando acesso a página principal da conta
    Então devo visualizar as informações disponíveis da minha conta
    E devo conseguir identificar o saldo atual

  @consistencia
  Cenário: Conferir o saldo depois de uma transferência
    Dado que fiz uma transferência com sucesso
    Quando volto para a página principal da conta
    Então o saldo exibido deve considerar o valor transferido
