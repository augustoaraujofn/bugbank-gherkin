# language: pt
@login
Funcionalidade: Login
  Quero entrar no BugBank com meus dados
  Para acessar minha conta

  Contexto:
    Dado que estou na página inicial do BugBank

  @positivo @smoke
  Cenário: Entrar com e-mail e senha corretos
    Dado que já tenho uma conta cadastrada
    Quando informo meu e-mail cadastrado
    E digito minha senha corretamente
    E clico em acessar
    Então devo entrar na minha conta
    E devo visualizar a área principal do sistema

  @negativo
  Cenário: Tentar entrar com a senha incorreta
    Dado que já tenho uma conta cadastrada
    Quando informo meu e-mail cadastrado
    E digito uma senha incorreta
    E clico em acessar
    Então não devo conseguir entrar
    E a aplicação deve informar que os dados de acesso são inválidos

  @negativo
  Cenário: Tentar entrar com um e-mail que não possui cadastro
    Quando informo um e-mail que não está cadastrado
    E preencho o campo de senha
    E clico em acessar
    Então o acesso deve ser recusado
    E a aplicação deve apresentar uma mensagem de erro

  @negativo
  Cenário: Tentar entrar sem preencher e-mail e senha
    Quando clico em acessar sem preencher os campos
    Então a aplicação deve indicar que os campos precisam ser preenchidos
    E não devo conseguir entrar
