# Análise inicial do BugBank

Fiz uma primeira olhada na aplicação antes de separar os cenários. A ideia desta página é deixar registrado o que considerei para montar a primeira versão do projeto.

## O que observei

Na tela inicial aparecem os campos de e-mail e senha, além das opções **Acessar** e **Registrar**. No formulário de registro, aparecem os campos de e-mail, nome, senha e confirmação de senha. Também existe a opção **Criar conta com saldo**.

Na página de requisitos da aplicação são listadas estas áreas:

- Login
- Cadastro
- Transferência
- Pagamento
- Extrato
- Saque

Nesta primeira versão, escrevi cenários para cadastro, login, consulta da conta, transferência e extrato. Pagamento e saque ficaram para uma próxima etapa.

## Pontos que preciso confirmar durante a execução

- Qual é o valor inicial atribuído quando a opção de criar conta com saldo está marcada e quando está desmarcada.
- Quais mensagens são exibidas em cada validação de cadastro e login.
- Como a aplicação trata valores no limite do saldo e outros valores inválidos na transferência.
- Se as informações criadas continuam disponíveis depois de atualizar a página ou iniciar outra sessão.

Preferi não inventar valores ou textos de mensagens antes de conferir o comportamento do sistema. Quando executar os cenários, vou atualizar esta análise com o que realmente encontrar.

## Cuidados com os dados

O próprio site informa que não possui banco de dados e que as informações são armazenadas em memória local. Vou usar somente contas e dados fictícios de teste e evitar depender de informações criadas em uma sessão anterior.

## Links consultados

- [Tela inicial do BugBank](https://bugbank.netlify.app/)
- [Requisitos apresentados pela aplicação](https://bugbank.netlify.app/requirements)
