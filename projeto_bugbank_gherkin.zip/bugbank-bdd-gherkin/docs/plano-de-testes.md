# Plano de testes — BugBank

## Objetivo

Organizar os testes que pretendo fazer nos principais fluxos do BugBank. Nesta etapa, os casos estão descritos em Gherkin e serão executados manualmente.

## O que vou testar

- Cadastro de uma nova conta;
- Login com dados válidos e inválidos;
- Consulta das informações da conta e do saldo;
- Transferência entre duas contas;
- Consulta do extrato.

Pagamento e saque não entraram nesta primeira versão. Quero detalhar esses fluxos antes de acrescentar novos cenários.

## O que não faz parte desta etapa

- Automação dos testes;
- Testes de carga ou desempenho;
- Testes de segurança;
- Integração com bancos reais ou movimentação de dinheiro de verdade.

## Como pretendo executar

Vou usar contas fictícias criadas no próprio BugBank. Para os cenários de transferência, preciso de duas contas e dos saldos conhecidos antes de começar. Assim consigo comparar o valor antes e depois da operação.

Durante a execução, vou registrar:

- Cenário que foi testado;
- Data e navegador utilizado;
- Resultado: passou, falhou ou ficou bloqueado;
- O que aconteceu, principalmente quando for diferente do esperado;
- Captura de tela ou vídeo, quando ajudar a demonstrar o resultado;
- Número do bug report, caso encontre um defeito.

## Por onde começar

Vou priorizar cadastro e login para preparar as contas de teste. Depois, vou seguir para transferência e conferir se o saldo e o extrato acompanham a movimentação. A consulta da conta também entra nessa conferência.

## Quando considero um cenário concluído

Só vou marcar um cenário como executado depois de realizar os passos na aplicação e comparar o resultado com o que está escrito no `Então`. Se não conseguir executar, vou registrar o motivo em vez de considerar o teste aprovado.
