# Registro de defeito

Use este modelo quando o resultado encontrado for diferente do esperado e o problema puder ser reproduzido.

**Título:**  
**Funcionalidade:**  
**Cenário relacionado:**  
**Data:**  
**Ambiente (navegador / sistema):**  
**Prioridade:**  
**Severidade:**  

## Antes de começar

Descreva o que precisa estar preparado. Exemplo: usuário cadastrado e logado, com saldo conhecido.

## Passos para reproduzir

1. 
2. 
3. 

## Resultado esperado

O que deveria acontecer de acordo com o cenário?

## Resultado encontrado

O que aconteceu durante o teste?

## Evidências

- Captura de tela ou vídeo:
- Dados de teste utilizados (sem informações reais):
- Frequência: acontece sempre ou ocorreu uma vez?

## Observações

Inclua algum detalhe que ajude outra pessoa a repetir o teste ou entender o problema.
